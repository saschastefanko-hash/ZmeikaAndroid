ЗМЕЙКА — Android-проект

Это готовый исходный проект Android-приложения. Для получения APK:
1. Установите Android Studio.
2. Откройте папку ZmeikaAndroid через File → Open.
3. Дождитесь синхронизации Gradle.
4. Выберите Build → Build Bundle(s) / APK(s) → Build APK(s).
5. APK появится в app/build/outputs/apk/debug/app-debug.apk.

Приложение работает офлайн, интернет-разрешение не запрашивается.
Минимальная версия Android: 6.0 (API 23).
